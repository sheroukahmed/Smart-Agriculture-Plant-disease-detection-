import 'dart:convert';
import 'dart:io';
import 'package:apptrial/shared/Components/Components.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class posting extends StatefulWidget {
  @override
  _postingState createState() => _postingState();
}

class _postingState extends State<posting> {
  late File _image;
  late String _response = '';

  final picker = ImagePicker();

  Future getImage_gallery() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);
    // setState(() {
      if (pickedFile != null) {
        setState(() {
          _image = File(pickedFile.path);
        });
      }
      // if (pickedFile != null) {
      //   _image = File(pickedFile.path);
      // } else {
      //   print('No image selected.');
      // }
    // });
  }

  Future getImage_camera() async {
    final image = await picker.getImage(source: ImageSource.camera);
    if (image == null) return null;
    setState(() {
      _image = File(image.path);
    });
  }

  Future sendImage() async {
    if (_image == null) {
      // Add null check here
      print('No image selected.');
      return;
    }

    // Replace this URL with the API endpoint that expects an image file
    final url =
        Uri.parse('https://f66e-156-204-100-228.ngrok-free.app/disease');

    try {
      final request = http.MultipartRequest('POST', url);
      request.files
          .add(await http.MultipartFile.fromPath('image', _image!.path));
      final response = await request.send();

      if (response.statusCode == 200) {
        final responseData =
            await response.stream.transform(utf8.decoder).join();
        setState(() {
          _response = responseData;
        });
      } else {
        print('Error: ${response.reasonPhrase}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.green.shade800,
          automaticallyImplyLeading: false,
          leading: const BackButton(
            color: Colors.black,
          )),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.green.shade50,
              Colors.white,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              if (_image != null)
                Image.file(
                  _image!,
                  height: 200,
                )
              else
                Image.asset(
                  'images/placeholder-png-image_3416659.jpeg',
                  height: 200,
                ),
              SizedBox(height: 16),
              CustomMaterialButton(
                onPressed: sendImage,
                text: 'Send Image',
              ),
              if (_response != null)
              SizedBox(height: 16),
              Text(_response!), // Add null check here
            ],
          ),
        ),
      ),
      floatingActionButton: SpeedDial(
        animatedIcon: AnimatedIcons.add_event,
        backgroundColor: Colors.green.shade800,
        children: [
          SpeedDialChild(
              child: Icon(Icons.camera),
              label: 'camera',
              onTap: () {
                getImage_camera();
              }),
          SpeedDialChild(
              child: Icon(Icons.image),
              label: 'Gallery',
              onTap: () {
                getImage_gallery();
              }),
        ],
      ),
    );
  }
}
