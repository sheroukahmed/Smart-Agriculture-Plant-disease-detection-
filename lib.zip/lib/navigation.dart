import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:apptrial/modules/profile/ProfileSections.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:apptrial/help_secreen.dart';

import 'modules/history/history.dart';
import 'modules/home/home_screen.dart';
import 'modules/profile/profile.dart';
import 'modules/settings/settings.dart';

class navigator extends StatefulWidget {
  @override
  State<navigator> createState() => _navigatorState();
}

class _navigatorState extends State<navigator> {
  int bottom_navigate = 1;

  final List<IconData> iconList = [
    Icons.energy_savings_leaf,
    Icons.home,
    Icons.person,
    Icons.settings
  ];

  final List<String> titleList = [
    'Home',
    'History',
    'Profile',
    'Settings'
  ];

  void onTabTapped(int index) {
    setState(() {
      bottom_navigate = index;
    });
  }

  Widget getScreen() {
    switch (bottom_navigate) {
      case 0:
        return ExampleParallax();
      case 1:
        return homeScreen();
      case 2:
        return ProfileScreen();
      case 3:
        return SettingScreen();
      default:
        return homeScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text(titleList[bottom_navigate]),
      //   backgroundColor: Colors.green.shade800,
      // ),
      body: Container(
          child: getScreen()
      ),
      bottomNavigationBar: CurvedNavigationBar(
        backgroundColor: Colors.green.shade800,
        items: <Widget>[
          Icon(iconList[0], size: 30),
          Icon(iconList[1], size: 30),
          Icon(iconList[2], size: 30),
          Icon(iconList[3], size: 30),
        ],
        index: bottom_navigate,
        onTap: onTabTapped,
      ),
    );
  }
}
