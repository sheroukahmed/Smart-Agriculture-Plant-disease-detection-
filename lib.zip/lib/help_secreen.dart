
import 'package:flutter/material.dart';



class HelpScreen extends StatelessWidget {
  const HelpScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade800,
        title: Text('Help Center'),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.green.shade50,
              Colors.white,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView(
          children: [
            Card(
              child: ListTile(
                leading: Icon(Icons.mail),
                title: Text('Contact Support'),
                onTap: () async {
                  // replace with your support email
                  // final Uri emailLaunchUri = Uri(
                  //   scheme: 'mailto',
                  //   path: 'support@example.com',
                  // );
                  // if (await canLaunch(emailLaunchUri.toString())) {
                  //   await launch(emailLaunchUri.toString());
                  // }
                },
              ),
            ),
            Card(
              child: ListTile(
                leading: Icon(Icons.privacy_tip),
                title: Text('Privacy Policy'),
                onTap: () async {
                  // replace with your privacy policy URL
                  // final Uri privacyPolicyUri = Uri.parse(
                  //     'https://www.example.com/privacy-policy');
                  // if (await canLaunch(privacyPolicyUri.toString())) {
                  //   await launch(privacyPolicyUri.toString());
                  // }
                },
              ),
            ),
            Card(
              child: ListTile(
                leading: Icon(Icons.description),
                title: Text('Terms of Service'),
                onTap: () async {
                  // replace with your terms of service URL
                  // final Uri termsOfServiceUri = Uri.parse(
                  //     'https://www.example.com/terms-of-service');
                //   if (await canLaunch(termsOfServiceUri.toString())) {
                //     await launch(termsOfServiceUri.toString());
                //   }
                 },
              ),
            ),
          ],
        ),
      ),
    );
  }
}