
import 'dart:io';
import 'package:apptrial/Camera.dart';
import 'package:apptrial/Modules/Home/home_screen.dart';
import 'package:apptrial/aydehk.dart';
import 'package:apptrial/mange_account.dart';
import 'package:apptrial/modules/welcome/welcome_screen.dart';
import 'package:apptrial/home.dart';
import 'package:apptrial/navigation.dart';
import 'package:apptrial/post.dart';
import 'package:apptrial/signup.dart';
import 'package:apptrial/modules/profile/profile.dart';
import 'package:flutter/material.dart';
import 'package:apptrial/modules/history/history.dart';
import 'package:apptrial/modules/settings/settings.dart';
import 'package:apptrial/Login.dart';
// import 'package:apptrial/pytmodel.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
// import 'package:pytorch_mobile/enums/dtype.dart';
// import 'package:pytorch_mobile/model.dart';
// import 'package:pytorch_mobile/pytorch_mobile.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_pytorch/flutter_pytorch.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:apptrial/notifications_screen.dart';
import 'package:apptrial/help_secreen.dart';
import 'auth.dart';




void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(myapp());

}


class myapp extends StatelessWidget
{
  const myapp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        darkTheme: ThemeData(
          scaffoldBackgroundColor: Colors.black54,
        ),
        home :navigator(),
      debugShowMaterialGrid: false,

    );
  }
}



